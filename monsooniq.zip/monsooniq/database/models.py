"""Relational schema (SQLAlchemy Core)."""
from sqlalchemy import (Column, DateTime, Date, Float, ForeignKey, Integer, MetaData,
                        String, Table, UniqueConstraint, func)

metadata = MetaData()

locations = Table(
    "locations", metadata,
    Column("id", Integer, primary_key=True, autoincrement=True),
    Column("name", String(150), nullable=False),
    Column("latitude", Float, nullable=False),
    Column("longitude", Float, nullable=False),
    UniqueConstraint("name", name="uq_location_name"),
)

weather_data = Table(
    "weather_data", metadata,
    Column("id", Integer, primary_key=True, autoincrement=True),
    Column("timestamp", DateTime, nullable=False),
    Column("location_id", Integer, ForeignKey("locations.id", ondelete="CASCADE"), nullable=False),
    Column("rainfall_mm", Float),
    Column("temperature", Float),
    Column("humidity", Float),
    Column("wind_speed", Float),
    Column("source", String(255)),
)

waterlogging_incidents = Table(
    "waterlogging_incidents", metadata,
    Column("id", Integer, primary_key=True, autoincrement=True),
    Column("date", Date, nullable=False),
    Column("location_id", Integer, ForeignKey("locations.id", ondelete="CASCADE"), nullable=False),
    Column("severity", String(50)),
    Column("duration", Float),
    Column("rainfall_mm", Float),
    Column("source", String(255)),
)

predictions = Table(
    "predictions", metadata,
    Column("id", Integer, primary_key=True, autoincrement=True),
    Column("timestamp", DateTime, server_default=func.now()),
    Column("location_id", Integer, ForeignKey("locations.id", ondelete="CASCADE"), nullable=False),
    Column("risk_category", String(20)),
    Column("risk_probability", Float),
    Column("model_version", String(50)),
)

model_metrics = Table(
    "model_metrics", metadata,
    Column("id", Integer, primary_key=True, autoincrement=True),
    Column("model_name", String(100)),
    Column("accuracy", Float),
    Column("precision", Float),
    Column("recall", Float),
    Column("f1_score", Float),
    Column("roc_auc", Float),
    Column("trained_at", DateTime, server_default=func.now()),
)


def create_tables(engine) -> None:
    metadata.create_all(engine)
