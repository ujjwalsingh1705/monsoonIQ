"""MySQL connection handling via SQLAlchemy + mysql-connector-python."""
import os
from urllib.parse import quote_plus

import streamlit as st
from dotenv import load_dotenv
from sqlalchemy import create_engine, text
from sqlalchemy.engine import Engine

# .env is the project's explicit configuration source.
# override=True prevents stale Windows environment variables from silently
# replacing the values the user put in this project's .env file.
load_dotenv(override=True)


def _url() -> str:
    user = os.getenv("MYSQL_USER", "").strip()
    password = os.getenv("MYSQL_PASSWORD", "")
    host = os.getenv("MYSQL_HOST", "localhost").strip() or "localhost"
    port = os.getenv("MYSQL_PORT", "3306").strip() or "3306"
    database = os.getenv("MYSQL_DATABASE", "monsooniq").strip() or "monsooniq"

    if not user:
        raise RuntimeError("MYSQL_USER is missing in .env")

    return (
        f"mysql+mysqlconnector://{quote_plus(user)}:{quote_plus(password)}"
        f"@{host}:{port}/{database}"
    )


@st.cache_resource(show_spinner=False)
def get_engine() -> Engine:
    return create_engine(
        _url(),
        pool_pre_ping=True,
        pool_recycle=1800,
        future=True,
    )


def test_connection() -> tuple[bool, str]:
    try:
        with get_engine().connect() as conn:
            conn.execute(text("SELECT 1"))
        return True, (
            f"Connected to {os.getenv('MYSQL_HOST', 'localhost')}/"
            f"{os.getenv('MYSQL_DATABASE', 'monsooniq')}"
        )
    except Exception as e:  # noqa: BLE001
        message = str(e).splitlines()[0][:240]
        return False, f"MySQL connection failed: {type(e).__name__}: {message}"


def db_available() -> bool:
    return test_connection()[0]
