"""Data access helpers. All functions raise on DB errors; pages catch and display them."""
from datetime import datetime

import pandas as pd
from sqlalchemy import insert, select, text

from database.connection import get_engine
from database.models import (create_tables, locations, model_metrics, predictions,
                             waterlogging_incidents, weather_data)


def init_db() -> None:
    create_tables(get_engine())


def read_sql(sql: str, params: dict | None = None) -> pd.DataFrame:
    with get_engine().connect() as conn:
        return pd.read_sql(text(sql), conn, params=params or {})


def get_locations() -> pd.DataFrame:
    return read_sql("SELECT id, name, latitude, longitude FROM locations ORDER BY name")


def upsert_location(conn, name: str, lat: float, lon: float) -> int:
    row = conn.execute(select(locations.c.id).where(locations.c.name == name)).first()
    if row:
        return row[0]
    return conn.execute(insert(locations).values(name=name, latitude=lat, longitude=lon)).inserted_primary_key[0]


def add_location(name: str, lat: float, lon: float) -> int:
    with get_engine().begin() as conn:
        return upsert_location(conn, name, lat, lon)


def import_dataset(df: pd.DataFrame) -> dict:
    """Import a validated dataframe (template columns) into MySQL."""
    counts = {"locations": 0, "weather_rows": 0, "incidents": 0}
    with get_engine().begin() as conn:
        before = conn.execute(text("SELECT COUNT(*) FROM locations")).scalar()
        loc_ids = {}
        for (name, lat, lon) in df[["location_name", "latitude", "longitude"]].drop_duplicates("location_name").itertuples(index=False):
            loc_ids[name] = upsert_location(conn, str(name), float(lat), float(lon))
        counts["locations"] = conn.execute(text("SELECT COUNT(*) FROM locations")).scalar() - before

        def val(r, c):
            v = r.get(c)
            return None if v is None or (isinstance(v, float) and pd.isna(v)) or (v is pd.NaT) else v

        w_rows, i_rows = [], []
        for r in df.to_dict("records"):
            lid = loc_ids[r["location_name"]]
            ts = pd.to_datetime(r["date"]).to_pydatetime()
            src = val(r, "source") or "user upload"
            w_rows.append(dict(timestamp=ts, location_id=lid, rainfall_mm=val(r, "rainfall_mm"),
                               temperature=val(r, "temperature"), humidity=val(r, "humidity"),
                               wind_speed=val(r, "wind_speed"), source=src))
            wl = val(r, "waterlogging")
            if wl is not None and int(wl) == 1:
                i_rows.append(dict(date=ts.date(), location_id=lid, severity=val(r, "severity"),
                                   duration=val(r, "duration_hours"), rainfall_mm=val(r, "rainfall_mm"), source=src))
        if w_rows:
            conn.execute(insert(weather_data), w_rows)
        if i_rows:
            conn.execute(insert(waterlogging_incidents), i_rows)
        counts["weather_rows"], counts["incidents"] = len(w_rows), len(i_rows)
    return counts


def get_weather_history() -> pd.DataFrame:
    return read_sql("""SELECT w.timestamp, w.rainfall_mm, w.temperature, w.humidity, w.wind_speed,
                              l.name AS location_name, l.latitude, l.longitude, w.source
                       FROM weather_data w JOIN locations l ON l.id = w.location_id""")


def get_incidents() -> pd.DataFrame:
    return read_sql("""SELECT i.date, i.severity, i.duration, i.rainfall_mm, i.source,
                              l.id AS location_id, l.name AS location_name, l.latitude, l.longitude
                       FROM waterlogging_incidents i JOIN locations l ON l.id = i.location_id""")


def incident_count_for(location_id: int) -> int:
    df = read_sql("SELECT COUNT(*) AS n FROM waterlogging_incidents WHERE location_id = :lid", {"lid": location_id})
    return int(df["n"].iloc[0])


def get_training_view() -> pd.DataFrame:
    """Weather observations joined with an observed-incident label (same location & day)."""
    return read_sql("""SELECT w.timestamp AS date, l.name AS location_name, l.latitude, l.longitude,
                              w.rainfall_mm, w.temperature, w.humidity, w.wind_speed,
                              CASE WHEN EXISTS (SELECT 1 FROM waterlogging_incidents i
                                                WHERE i.location_id = w.location_id AND i.date = DATE(w.timestamp))
                                   THEN 1 ELSE 0 END AS waterlogging
                       FROM weather_data w JOIN locations l ON l.id = w.location_id""")


def save_prediction(location_id: int, category: str, prob: float, version: str) -> None:
    with get_engine().begin() as conn:
        conn.execute(insert(predictions).values(timestamp=datetime.now(), location_id=location_id,
                                                risk_category=category, risk_probability=prob, model_version=version))


def get_latest_predictions() -> pd.DataFrame:
    return read_sql("""SELECT p.timestamp, p.risk_category, p.risk_probability, p.model_version,
                              l.id AS location_id, l.name AS location_name, l.latitude, l.longitude
                       FROM predictions p JOIN locations l ON l.id = p.location_id
                       WHERE p.id IN (SELECT MAX(id) FROM predictions GROUP BY location_id)""")


def save_metrics(m: dict) -> None:
    with get_engine().begin() as conn:
        conn.execute(insert(model_metrics).values(**m))


def get_metrics_history() -> pd.DataFrame:
    return read_sql("SELECT * FROM model_metrics ORDER BY trained_at DESC")


def table_counts() -> dict:
    out = {}
    for t in ["locations", "weather_data", "waterlogging_incidents", "predictions", "model_metrics"]:
        out[t] = int(read_sql(f"SELECT COUNT(*) AS n FROM {t}")["n"].iloc[0])
    return out
