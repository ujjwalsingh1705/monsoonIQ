"""MONSOONIQ — Mumbai Waterlogging Intelligence System. Run: streamlit run app.py"""
from pathlib import Path

import streamlit as st

st.set_page_config(page_title="MONSOONIQ · Mumbai Waterlogging Intelligence", page_icon="💧", layout="wide")

ROOT = Path(__file__).parent
st.markdown(f"<style>{(ROOT / 'styles' / 'style.css').read_text()}</style>", unsafe_allow_html=True)

from database.connection import db_available  # noqa: E402

if "db_init" not in st.session_state:
    st.session_state.db_init = False
    if db_available():
        try:
            from database.queries import init_db
            init_db()
            st.session_state.db_init = True
        except Exception as e:  # noqa: BLE001
            st.session_state.db_error = str(e)

with st.sidebar:
    st.markdown("<div class='brand'><div class='brand-row'><div class='brand-mark'></div>"
                "<div class='brand-name'>MONSOON<span>IQ</span></div></div>"
                "<div class='brand-sub'>Mumbai Waterlogging Intelligence</div></div>", unsafe_allow_html=True)

pages = {
    "Intelligence": [
        st.Page("pages/dashboard.py", title="Command Center", icon=":material/radar:", default=True),
        st.Page("pages/risk_analysis.py", title="Risk Intelligence", icon=":material/neurology:"),
        st.Page("pages/risk_map.py", title="Mumbai Map", icon=":material/map:"),
        st.Page("pages/analytics.py", title="Historical Data", icon=":material/insights:"),
    ],
    "Model": [
        st.Page("pages/model_training.py", title="Model Training", icon=":material/model_training:"),
        st.Page("pages/model_performance.py", title="Model Intelligence", icon=":material/monitoring:"),
    ],
    "System": [
        st.Page("pages/data_management.py", title="Data Management", icon=":material/database:"),
        st.Page("pages/settings.py", title="Settings", icon=":material/tune:"),
    ],
}
st.navigation(pages).run()

with st.sidebar:
    st.caption("Risk outputs are statistical estimates based on uploaded verified data.")
