import pandas as pd
import plotly.graph_objects as go
import streamlit as st

from api import weather
from api.maps import MUMBAI_CENTER
from database.connection import test_connection
from ml.predict import get_meta
from ui import BLUE, CYAN, RISK_COLORS, VIOLET, card, fmt, hero, section, skeletons, status_strip

hero()
ph = st.empty()
with ph.container():
    skeletons(4)

ok, msg = test_connection()
meta = get_meta()
data = {"locations": pd.DataFrame(), "incidents": pd.DataFrame(), "preds": pd.DataFrame()}
if ok:
    from database import queries as q
    try:
        data = {"locations": q.get_locations(), "incidents": q.get_incidents(), "preds": q.get_latest_predictions()}
    except Exception as e:  # noqa: BLE001
        st.error(f"Could not load data: {e}")

w, werr = None, None
if weather.is_configured():
    try:
        w = weather.get_current_weather(*MUMBAI_CENTER)
    except weather.WeatherError as e:
        werr = str(e)
ph.empty()

status_strip([
    ("DATA STREAM ACTIVE" if ok else "DATA STREAM OFFLINE", "ok" if ok else "off"),
    ("WEATHER API CONNECTED" if w else ("WEATHER API ERROR" if werr else "WEATHER API NOT CONFIGURED"), "ok" if w else ("off" if werr else "warn")),
    ("MODEL ONLINE" if meta else "MODEL OFFLINE", "ok" if meta else "off"),
])
if not ok:
    st.error(f"{msg}. Configure MySQL in .env — see Settings.")
if werr:
    st.warning(werr)

locs, inc, preds = data["locations"], data["incidents"], data["preds"]
latest = preds.sort_values("timestamp").iloc[-1] if not preds.empty else None

c = st.columns(4)
with c[0]:
    if latest is not None:
        cat = latest["risk_category"]
        card("Current risk", cat.upper(), f"{latest['location_name']} · {str(latest['timestamp'])[:16]}",
             accent=RISK_COLORS[cat], value_color=RISK_COLORS[cat], tag="LATEST")
    else:
        card("Current risk", "—", "no prediction run yet", tag="LATEST")
with c[1]:
    if latest is not None:
        card("Model confidence", f"{latest['risk_probability'] * 100:.1f}", f"risk probability · {latest['model_version']}", unit="%", accent=VIOLET, delay=1)
    else:
        card("Model confidence", "—", meta["version"] if meta else "model offline", accent=VIOLET, delay=1)
with c[2]:
    card("Rainfall", fmt(w and w["rainfall_mm"]), f"{w['condition']} · {w['rainfall_window']}" if w else "live weather unavailable",
         unit="mm" if w else "", accent=BLUE, delay=2, tag="LIVE")
with c[3]:
    card("Active locations", len(locs), f"{len(inc)} historical incidents", accent=CYAN, delay=3)

if w:
    st.write("")
    c = st.columns(4)
    with c[0]: card("Temperature", fmt(w["temperature"]), "Mumbai city centre", unit="°C")
    with c[1]: card("Humidity", fmt(w["humidity"], 0), "relative", unit="%", delay=1)
    with c[2]: card("Wind", fmt(w["wind_speed"]), "surface", unit="m/s", delay=2)
    with c[3]: card("Observed", w["timestamp"][11:], w["timestamp"][:10] + " · " + w["source"], delay=3)

left, right = st.columns([3, 2], gap="large")
with left:
    section("Latest predictions")
    if preds.empty:
        st.caption("No predictions yet. Run one from Risk Intelligence.")
    else:
        p = preds.sort_values("risk_probability")
        fig = go.Figure(go.Bar(x=p.risk_probability, y=p.location_name, orientation="h",
                               marker=dict(color=[RISK_COLORS[c] for c in p.risk_category], line=dict(width=0)),
                               hovertemplate="%{y}<br>%{x:.1%}<extra></extra>"))
        fig.update_layout(height=max(260, 34 * len(p) + 80), xaxis=dict(tickformat=".0%", range=[0, 1]), title="Predicted risk probability by location")
        st.plotly_chart(fig, use_container_width=True)
with right:
    section("Risk distribution")
    if preds.empty:
        st.caption("Distribution appears once predictions exist.")
    else:
        dist = preds.risk_category.value_counts().reindex(["Low", "Moderate", "High"]).fillna(0)
        fig = go.Figure(go.Pie(labels=dist.index, values=dist.values, hole=.72, sort=False,
                               marker=dict(colors=[RISK_COLORS[k] for k in dist.index], line=dict(color="#05080f", width=3))))
        fig.update_layout(height=320, showlegend=True, legend=dict(orientation="h", y=-0.05),
                          annotations=[dict(text=f"<b>{int(dist.sum())}</b><br>locations", showarrow=False, font=dict(size=16, family="Sora"))])
        st.plotly_chart(fig, use_container_width=True)
    section("Most affected locations")
    if inc.empty:
        st.caption("No incident data imported yet.")
    else:
        top = inc.groupby("location_name").size().nlargest(8).sort_values()
        fig = go.Figure(go.Bar(x=top.values, y=top.index, orientation="h", marker=dict(color=top.values, colorscale=[[0, BLUE], [1, CYAN]])))
        fig.update_layout(height=300, title="Recorded incidents")
        st.plotly_chart(fig, use_container_width=True)
