import pandas as pd
import plotly.graph_objects as go
import streamlit as st

from api import weather
from api.maps import MUMBAI_CENTER
from database.connection import test_connection
from ui import BLUE, CYAN, RISK_COLORS, esc, header

header(
    "Spatial Intelligence",
    "Mumbai Map",
    "Monitored locations, historical incidents and predicted risk across Mumbai.",
)

# Database
ok, msg = test_connection()
if not ok:
    st.error(msg)
    st.stop()

from database import queries as q

try:
    locs = q.get_locations()
    inc = q.get_incidents()
    preds = q.get_latest_predictions()
except Exception as e:
    st.error(f"Could not load map data: {e}")
    st.stop()

# Live weather
current_weather = None
if weather.is_configured():
    try:
        current_weather = weather.get_current_weather(
            MUMBAI_CENTER[0],
            MUMBAI_CENTER[1],
        )
    except Exception:
        current_weather = None

# Sidebar / right panel
mapcol, panel = st.columns([4, 1], gap="medium")

with panel:
    show_inc = st.toggle("Waterlogging incidents", True)
    show_pred = st.toggle("Predicted risk", True)
    show_loc = st.toggle("Monitored locations", True)

    rainfall_text = "n/a"
    if current_weather:
        try:
            rainfall_text = f"{float(current_weather.get('rainfall_mm', 0)):.1f} mm"
        except (TypeError, ValueError):
            rainfall_text = "n/a"

    high_count = 0
    if preds is not None and not preds.empty and "risk_category" in preds.columns:
        high_count = int(
            (preds["risk_category"].astype(str).str.lower() == "high").sum()
        )

    rows = [
        ("LIVE RAINFALL", BLUE, rainfall_text),
        ("WATERLOGGING INCIDENTS", CYAN, str(len(inc))),
        ("PREDICTED HIGH RISK", RISK_COLORS.get("High", "#ff416c"), str(high_count)),
        ("MONITORED LOCATIONS", "#7d8aa8", str(len(locs))),
    ]

    st.markdown(
        "<div class='layer-panel'>"
        + "".join(
            f"<div class='layer-row'><i class='ldot' style='color:{color}'></i>"
            f"{esc(label)}<span class='v'>{esc(value)}</span></div>"
            for label, color, value in rows
        )
        + "</div>",
        unsafe_allow_html=True,
    )

    st.write("")

    st.markdown(
        "<div class='layer-panel'>"
        + "".join(
            f"<div class='layer-row'><i class='ldot' style='color:{color}'></i>"
            f"{esc(category.upper())}</div>"
            for category, color in RISK_COLORS.items()
        )
        + "</div>",
        unsafe_allow_html=True,
    )


# Map