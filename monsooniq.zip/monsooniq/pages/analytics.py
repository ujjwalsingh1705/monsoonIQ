import pandas as pd
import plotly.graph_objects as go
import streamlit as st

from database.connection import test_connection
from ui import BLUE, CYAN, RISK_COLORS, VIOLET, header

header("Historical Data", "What has happened historically", "Every chart reads directly from imported MySQL records.")

ok, msg = test_connection()
if not ok:
    st.error(msg)
    st.stop()
from database import queries as q

try:
    w, inc, preds = q.get_weather_history(), q.get_incidents(), q.get_latest_predictions()
except Exception as e:  # noqa: BLE001
    st.error(f"Could not load history: {e}")
    st.stop()
if w.empty and inc.empty:
    st.info("No historical data yet. Import a verified dataset in Data Management.")
    st.stop()

w["timestamp"] = pd.to_datetime(w["timestamp"])
inc["date"] = pd.to_datetime(inc["date"])
sel = st.multiselect("Filter locations", sorted(set(w.location_name) | set(inc.location_name)), placeholder="All Mumbai locations")
if sel:
    w, inc = w[w.location_name.isin(sel)], inc[inc.location_name.isin(sel)]


def glow_line(x, y, name, color, title):
    f = go.Figure()
    f.add_trace(go.Scatter(x=x, y=y, mode="lines", line=dict(color=color, width=8, shape="spline"), opacity=.15, hoverinfo="skip", showlegend=False))
    f.add_trace(go.Scatter(x=x, y=y, mode="lines", name=name, line=dict(color=color, width=2, shape="spline"),
                           fill="tozeroy", fillcolor="rgba(34,211,238,0.08)"))
    if len(y):
        i = int(pd.Series(y).idxmax()) if isinstance(y, pd.Series) else 0
        f.add_trace(go.Scatter(x=[x.iloc[i]], y=[y.iloc[i]], mode="markers", name="Peak",
                               marker=dict(size=12, color=color, line=dict(color="#fff", width=1.5))))
    f.update_layout(title=title, height=360, showlegend=False, hovermode="x unified")
    return f


t1, t2, t3, t4, t5 = st.tabs(["Rainfall Intelligence", "Waterlogging Trends", "Risk Distribution", "Rainfall vs Incidents", "Location Risk"])
with t1:
    if not w.empty:
        d = w.set_index("timestamp").resample("D")["rainfall_mm"].mean().dropna().reset_index()
        st.plotly_chart(glow_line(d.timestamp, d.rainfall_mm, "Rainfall", CYAN, "Daily mean rainfall (mm)"), use_container_width=True)
        c1, c2 = st.columns(2)
        m = w.assign(ym=w.timestamp.dt.to_period("M").astype(str)).groupby("ym")["rainfall_mm"].sum().reset_index()
        c1.plotly_chart(go.Figure(go.Bar(x=m.ym, y=m.rainfall_mm, marker=dict(color=m.rainfall_mm, colorscale=[[0, BLUE], [1, CYAN]])))
                        .update_layout(title="Monthly rainfall (sum of records)", height=340), use_container_width=True)
        s = w.assign(month=w.timestamp.dt.month).groupby("month")["rainfall_mm"].mean().reindex(range(1, 13)).reset_index()
        c2.plotly_chart(go.Figure(go.Barpolar(r=s.rainfall_mm, theta=[pd.Timestamp(2000, mm, 1).strftime("%b") for mm in s.month],
                                              marker=dict(color=s.rainfall_mm, colorscale=[[0, VIOLET], [1, CYAN]])))
                        .update_layout(title="Seasonal pattern — mean rainfall by month", height=340,
                                       polar=dict(bgcolor="rgba(0,0,0,0)", angularaxis=dict(direction="clockwise"))), use_container_width=True)
with t2:
    if inc.empty:
        st.caption("No incidents recorded.")
    else:
        ot = inc.set_index("date").resample("MS").size().reset_index(name="incidents")
        st.plotly_chart(glow_line(ot.date, ot.incidents, "Incidents", VIOLET, "Waterlogging incidents per month"), use_container_width=True)
        sm = inc.assign(month=inc.date.dt.month).groupby("month").size().reindex(range(1, 13), fill_value=0)
        st.plotly_chart(go.Figure(go.Bar(x=[pd.Timestamp(2000, m, 1).strftime("%b") for m in sm.index], y=sm.values, marker_color=VIOLET))
                        .update_layout(title="Seasonal pattern — incidents by month", height=320), use_container_width=True)
with t3:
    if preds.empty:
        st.caption("No predictions yet — run analyses from Risk Intelligence.")
    else:
        dist = preds.risk_category.value_counts().reindex(["Low", "Moderate", "High"]).fillna(0)
        st.plotly_chart(go.Figure(go.Bar(x=dist.index, y=dist.values, marker_color=[RISK_COLORS[k] for k in dist.index], width=.5))
                        .update_layout(title="Latest predicted risk across monitored locations", height=360), use_container_width=True)
    if not inc.empty and inc.severity.notna().any():
        sv = inc.severity.fillna("Unknown").value_counts()
        st.plotly_chart(go.Figure(go.Pie(labels=sv.index, values=sv.values, hole=.7,
                                         marker=dict(colors=[RISK_COLORS.get(str(k).title(), "#7d8aa8") for k in sv.index])))
                        .update_layout(title="Recorded incident severity", height=340), use_container_width=True)
with t4:
    if not w.empty:
        w["day"] = w.timestamp.dt.normalize()
        keys = set(zip(inc.location_name, inc.date.dt.normalize()))
        w["waterlogging"] = [(l, d) in keys for l, d in zip(w.location_name, w.day)]
        bins = pd.cut(w.rainfall_mm, [-0.1, 10, 25, 50, 100, 200, 10000], labels=["0–10", "10–25", "25–50", "50–100", "100–200", "200+"])
        rate = w.groupby(bins, observed=False)["waterlogging"].agg(["mean", "size"]).reset_index()
        f = go.Figure(go.Bar(x=rate.rainfall_mm, y=rate["mean"], customdata=rate["size"], marker=dict(color=rate["mean"], colorscale=[[0, "#34d399"], [.5, "#fbbf24"], [1, "#f43f5e"]]),
                             hovertemplate="%{x} mm<br>%{y:.1%} waterlogged<br>%{customdata} records<extra></extra>"))
        st.plotly_chart(f.update_layout(title="Observed waterlogging rate by rainfall band (mm)", height=360, yaxis_tickformat=".0%"), use_container_width=True)
        f = go.Figure()
        for flag, color, name in [(False, BLUE, "No waterlogging"), (True, "#f43f5e", "Waterlogging")]:
            f.add_trace(go.Box(y=w[w.waterlogging == flag].rainfall_mm, name=name, marker_color=color, boxmean=True))
        st.plotly_chart(f.update_layout(title="Rainfall distribution on days with vs without waterlogging", height=360), use_container_width=True)
with t5:
    if not inc.empty:
        lw = inc.groupby("location_name").size().nlargest(15).sort_values()
        st.plotly_chart(go.Figure(go.Bar(x=lw.values, y=lw.index, orientation="h", marker=dict(color=lw.values, colorscale=[[0, BLUE], [1, "#f43f5e"]])))
                        .update_layout(title="Most affected Mumbai areas", height=max(320, 30 * len(lw) + 80)), use_container_width=True)
