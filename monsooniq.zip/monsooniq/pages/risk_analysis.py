import pandas as pd
import streamlit as st

from api import maps, weather
from database.connection import test_connection
from ml.predict import PredictionError, get_meta, predict_risk
from ui import BLUE, VIOLET, ai_panel, card, explain, fmt, header, model_offline, section

header("Risk Intelligence", "Where is the risk — and why", "Select or search a Mumbai location, pull live weather and run the trained Random Forest model.")

ok, msg = test_connection()
meta = get_meta()

locs, inc_all = None, pd.DataFrame()
if ok:
    from database import queries as q
    try:
        locs, inc_all = q.get_locations(), q.get_incidents()
    except Exception as e:  # noqa: BLE001
        st.error(f"Could not load locations: {e}")
else:
    st.warning(msg)

left, right = st.columns([5, 7], gap="large")
with left:
    section("Target location")
    mode = st.radio("Source", ["Monitored", "Search Mumbai"], horizontal=True, label_visibility="collapsed")
    loc = None
    if mode == "Monitored":
        if locs is None or locs.empty:
            st.info("No monitored locations yet. Import data in Data Management, or search a location.")
        else:
            name = st.selectbox("Location", locs["name"])
            r = locs[locs.name == name].iloc[0]
            loc = {"id": int(r.id), "name": r["name"], "latitude": float(r.latitude), "longitude": float(r.longitude)}
    else:
        qtext = st.text_input("Search a place in Mumbai", placeholder="Hindmata, Milan Subway, Kurla…")
        if qtext:
            try:
                results = maps.search_location(qtext)
                if not results:
                    st.warning("No matches inside Mumbai.")
                else:
                    pick = st.selectbox("Results", range(len(results)), format_func=lambda i: results[i]["name"])
                    loc = dict(results[pick], id=None)
                    st.caption(f"Geocoded via {maps.provider()}")
            except maps.GeocodeError as e:
                st.error(str(e))

if not loc:
    with right:
        model_offline() if not meta else st.caption("Select a location to begin analysis.")
    st.stop()

loc_inc = inc_all[inc_all.location_id == loc["id"]] if loc["id"] and not inc_all.empty else pd.DataFrame()
hist = {}
if not inc_all.empty:
    hist["avg_loc_incidents"] = inc_all.groupby("location_id").size().mean()
    if inc_all.rainfall_mm.notna().any():
        hist["incident_rain_mean"] = float(inc_all.rainfall_mm.mean())
if loc["id"]:
    hist["loc_incidents"] = len(loc_inc)
if ok:
    try:
        wh = q.read_sql("SELECT AVG(rainfall_mm) AS m FROM weather_data")
        if wh.m.notna().any():
            hist["all_rain_mean"] = float(wh.m.iloc[0])
    except Exception:  # noqa: BLE001
        pass

with left:
    c = st.columns(2)
    with c[0]: card("Latitude", f"{loc['latitude']:.4f}", loc["name"][:28])
    with c[1]: card("Incidents", hist.get("loc_incidents", "—"), "recorded here", accent=VIOLET, delay=1)
    if not loc_inc.empty:
        with st.expander("Historical incidents"):
            st.dataframe(loc_inc[["date", "severity", "duration", "rainfall_mm", "source"]].sort_values("date", ascending=False),
                         hide_index=True, use_container_width=True)

    section("Live conditions")
    if st.button("Fetch current weather", use_container_width=True):
        try:
            st.session_state.weather = weather.get_current_weather(loc["latitude"], loc["longitude"])
            st.session_state.weather_for = loc["name"]
        except weather.WeatherError as e:
            st.error(str(e))
    w = st.session_state.weather if st.session_state.get("weather_for") == loc["name"] else None
    if w:
        c = st.columns(2)
        with c[0]: card("Rainfall", fmt(w["rainfall_mm"]), w["rainfall_window"], unit="mm", accent=BLUE, tag="LIVE")
        with c[1]: card("Condition", w["condition"], w["timestamp"], delay=1)
        c = st.columns(3)
        with c[0]: card("Temp", fmt(w["temperature"]), unit="°C")
        with c[1]: card("Humidity", fmt(w["humidity"], 0), unit="%", delay=1)
        with c[2]: card("Wind", fmt(w["wind_speed"]), unit="m/s", delay=2)

with right:
    if not meta:
        model_offline()
        st.stop()
    section("Model inputs")
    base = {"latitude": loc["latitude"], "longitude": loc["longitude"], "location_name": loc["name"]}
    if w:
        base.update({k: w[k] for k in ("rainfall_mm", "temperature", "humidity", "wind_speed")})
    if "loc_incidents" in hist:
        base["historical_incident_count"] = hist["loc_incidents"]
    inputs = {}
    derived = {"month", "day_of_year", "is_monsoon"}
    cols = st.columns(3)
    for i, f in enumerate([f for f in meta["features"] if f not in derived]):
        with cols[i % 3]:
            if f in meta["categorical"]:
                inputs[f] = st.text_input(f, value=str(base.get(f, "")) or "") or None
            else:
                v = base.get(f)
                inputs[f] = st.number_input(f, value=float(v) if v is not None else 0.0, format="%.4f", help="Live weather values are pre-filled when the weather API is available.")
    st.caption(f"Model {meta['version']} · live values pre-filled · date features use today's date.")

    if st.button("Run AI risk analysis", type="primary", use_container_width=True):
        try:
            with st.spinner("Analysing conditions…"):
                res = predict_risk(inputs)
            st.session_state.last_res = (loc["name"], res)
            if ok and loc["id"]:
                try:
                    q.save_prediction(loc["id"], res["risk_category"], res["risk_probability"], res["model_version"])
                except Exception as e:  # noqa: BLE001
                    st.warning(f"Prediction not saved: {e}")
        except PredictionError as e:
            st.error(str(e))

    last = st.session_state.get("last_res")
    if last and last[0] == loc["name"]:
        res = last[1]
        full_inputs = {**res["inputs"], **{k: v for k, v in inputs.items() if v is not None}}
        import datetime as _dt
        full_inputs.setdefault("is_monsoon", int(_dt.date.today().month in (6, 7, 8, 9)))
        st.write("")
        ai_panel(loc["name"].split(",")[0], res["risk_category"], res["risk_probability"], res["model_version"],
                 explain(full_inputs, meta, hist))
        if ok and not loc["id"] and st.button("Add to monitored locations & save prediction"):
            lid = q.add_location(loc["name"][:150], loc["latitude"], loc["longitude"])
            q.save_prediction(lid, res["risk_category"], res["risk_probability"], res["model_version"])
            st.success("Saved.")
