import os

import streamlit as st

from api import maps, weather
from database.connection import test_connection
from ml.predict import get_meta, load_artifacts
from ml.train import MODEL_PATH
from ui import chip as badge, header

header("System", "Settings & status", "Configuration is read from .env. Secret values are never displayed.")


def row(name, html_badge, detail=""):
    st.markdown(f"**{name}** &nbsp; {html_badge}<br><span style='color:#8aa0b0;font-size:.85rem'>{detail}</span>", unsafe_allow_html=True)
    st.divider()


ok, msg = test_connection()
row("MySQL", badge("connected", "ok") if ok else badge("unavailable", "bad"), msg)
if ok:
    from database.queries import table_counts
    try:
        st.json(table_counts())
    except Exception as e:  # noqa: BLE001
        st.caption(str(e))

if weather.is_configured():
    if st.button("Test weather API"):
        try:
            weather.get_current_weather(*maps.MUMBAI_CENTER)
            st.success("Weather API responded.")
        except weather.WeatherError as e:
            st.error(str(e))
    row("Weather API (OpenWeatherMap)", badge("key configured", "ok"), "OPENWEATHER_API_KEY is set (value hidden).")
else:
    row("Weather API (OpenWeatherMap)", badge("not configured", "warn"), "Set OPENWEATHER_API_KEY in .env.")

row("Maps / geocoding", badge(maps.provider(), "ok"),
    "GOOGLE_MAPS_API_KEY set (value hidden)." if os.getenv("GOOGLE_MAPS_API_KEY") else "Using keyless OpenStreetMap Nominatim; map tiles by CARTO/OSM.")

meta = get_meta()
if meta:
    row("Model", badge("trained", "ok"), f"{meta['version']} · {MODEL_PATH.name} · features: {', '.join(meta['features'])}")
else:
    row("Model", badge("not trained", "warn"), "Upload verified data and train the model first.")
if st.button("Reload model from disk"):
    st.cache_resource.clear()
    load_artifacts()
    st.rerun()
