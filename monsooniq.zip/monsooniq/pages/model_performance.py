import pandas as pd
import plotly.express as px
import streamlit as st

from database.connection import test_connection
from ml.predict import NO_MODEL_MSG, get_meta
from ui import card, header, model_offline

header("Model Intelligence", "Model Performance", "Metrics of the currently saved model, computed on the held-out test set.")
meta = get_meta()
if not meta:
    model_offline()
    st.stop()
m = meta["metrics"]
c = st.columns(4)
with c[0]: card("Version", meta["version"], meta["trained_at"])
with c[1]: card("Training rows", f"{meta['train_size']:,}")
with c[2]: card("Test rows", f"{meta['test_size']:,}")
with c[3]: card("Dataset", meta["dataset"][:28], f"target: {meta['target']}")
st.write("")
c = st.columns(5)
for col, k in zip(c, ["accuracy", "precision", "recall", "f1_score", "roc_auc"]):
    with col: card(k.replace("_", " ").title(), "n/a" if m[k] is None else f"{m[k]:.3f}")
a, b = st.columns(2)
a.plotly_chart(px.imshow(m["confusion_matrix"], x=m["classes"], y=m["classes"], text_auto=True,
                         labels=dict(x="Predicted", y="Actual"), color_continuous_scale="Teal", title="Confusion matrix"), use_container_width=True)
fi = pd.DataFrame(meta["feature_importance"][:15], columns=["feature", "importance"]).sort_values("importance")
b.plotly_chart(px.bar(fi, x="importance", y="feature", orientation="h", title="Feature importance"), use_container_width=True)
st.json({"features": meta["features"], "params": meta["params"], "class_distribution": meta["class_distribution"]}, expanded=False)

ok, _ = test_connection()
if ok:
    try:
        from database.queries import get_metrics_history
        h = get_metrics_history()
        if not h.empty:
            st.subheader("Training history")
            st.dataframe(h, hide_index=True, use_container_width=True)
    except Exception as e:  # noqa: BLE001
        st.caption(f"History unavailable: {e}")
