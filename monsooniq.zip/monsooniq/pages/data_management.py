from datetime import datetime
from pathlib import Path

import pandas as pd
import streamlit as st

from database.connection import test_connection
from ml.preprocessing import clean, missing_summary, validate
from ui import header

ROOT = Path(__file__).resolve().parent.parent
UPLOADS = ROOT / "data" / "uploads"
TEMPLATE = ROOT / "data" / "templates" / "waterlogging_dataset_template.csv"
header("Data", "Data Management", "Upload verified Mumbai rainfall & waterlogging records, validate them and import into MySQL. Uploading never trains the model.")

st.download_button("Download CSV template", TEMPLATE.read_bytes(), "waterlogging_dataset_template.csv", "text/csv")
up = st.file_uploader("Upload verified dataset (CSV)", type=["csv"])
if not up:
    st.stop()
try:
    raw = pd.read_csv(up)
except Exception as e:  # noqa: BLE001
    st.error(f"Invalid CSV: {e}")
    st.stop()

is_demo = st.checkbox("This file is demo/sample data (will be labelled and blocked from training)")
if is_demo:
    st.markdown("<div class='demo-banner'>DEMO DATA — NOT FOR MODEL TRAINING</div>", unsafe_allow_html=True)

st.subheader("Preview")
st.dataframe(raw.head(100), use_container_width=True)
report = validate(raw)
c1, c2, c3 = st.columns(3)
c1.metric("Rows", f"{len(raw):,}")
c2.metric("Duplicates", int(raw.duplicated().sum()))
c3.metric("Missing cells", int(raw.isna().sum().sum()))
for e in report["errors"]:
    st.error(e)
for w in report["warnings"]:
    st.warning(w)
if not report["errors"]:
    st.success("Validation passed.")

with st.expander("Missing values"):
    ms = missing_summary(raw)
    st.dataframe(ms, use_container_width=True) if not ms.empty else st.caption("No missing values.")
with st.expander("Basic statistics"):
    st.dataframe(raw.describe(include="all").T, use_container_width=True)

if report["errors"]:
    st.stop()
df = clean(raw)
st.caption(f"{len(df):,} valid rows after cleaning.")
ok, msg = test_connection()
c1, c2 = st.columns(2)
if c1.button("Save as training dataset file"):
    UPLOADS.mkdir(parents=True, exist_ok=True)
    name = f"{'demo_' if is_demo else ''}{Path(up.name).stem}_{datetime.now():%Y%m%d%H%M%S}.csv"
    df.to_csv(UPLOADS / name, index=False)
    st.success(f"Saved as {name}. Train it from Model Training.")
if c2.button("Import valid records into MySQL", disabled=not ok or is_demo):
    try:
        from database.queries import import_dataset
        with st.spinner("Importing…"):
            n = import_dataset(df)
        st.success(f"Imported {n['weather_rows']} weather rows, {n['incidents']} incidents, {n['locations']} new locations.")
    except Exception as e:  # noqa: BLE001
        st.error(f"Import failed: {e}")
if not ok:
    st.caption(msg)
if is_demo:
    st.caption("Demo data is not imported into MySQL to keep historical analytics clean.")
