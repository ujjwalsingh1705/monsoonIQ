from pathlib import Path

import pandas as pd
import plotly.express as px
import streamlit as st

from database.connection import test_connection
from ml.preprocessing import add_date_features, candidate_features, clean
from ml.train import TrainingError, save_artifacts, train_model
from ui import header

UPLOADS = Path(__file__).resolve().parent.parent / "data" / "uploads"
header("Training", "Train the Random Forest", "Train only on verified real-world data. Training never runs automatically.")

sources = sorted(p.name for p in UPLOADS.glob("*.csv"))
ok, _ = test_connection()
options = (["MySQL: weather records labelled by recorded incidents"] if ok else []) + sources
if not options:
    st.info("No datasets available. Upload and validate a verified CSV in Data Management first.")
    st.stop()

src = st.selectbox("Dataset", options)
try:
    if src.startswith("MySQL"):
        from database.queries import get_training_view
        df = get_training_view()
    else:
        df = pd.read_csv(UPLOADS / src)
except Exception as e:  # noqa: BLE001
    st.error(f"Could not load dataset: {e}")
    st.stop()
if "demo" in src.lower():
    st.error("DEMO DATA — NOT FOR MODEL TRAINING. Choose a verified dataset.")
    st.stop()

df = add_date_features(clean(df))
if df.empty:
    st.error("Dataset is empty after cleaning.")
    st.stop()
st.caption(f"{len(df):,} rows · {df.shape[1]} columns after cleaning (duplicates removed, date features added)")
st.dataframe(df.head(50), use_container_width=True)

cols = list(df.columns)
target = st.selectbox("Target column", cols, index=cols.index("waterlogging") if "waterlogging" in cols else 0)
cands = candidate_features(df, target)
default = [c for c in ["rainfall_mm", "temperature", "humidity", "wind_speed", "latitude", "longitude", "month", "is_monsoon"] if c in cands]
features = st.multiselect("Input features", cands, default=default)
st.caption("Only select features that will also be available at prediction time (live weather provides rainfall, temperature, humidity, wind speed).")
c1, c2, c3 = st.columns(3)
test_size = c1.slider("Test split", 0.1, 0.4, 0.2, 0.05)
n_est = c2.slider("Trees", 50, 800, 300, 50)
depth = c3.select_slider("Max depth", [None, 4, 6, 8, 12, 16, 24], value=None)
st.write("Class balance:", df[target].value_counts(dropna=False).to_dict())

if st.button("Train model", type="primary"):
    try:
        with st.spinner("Training…"):
            st.session_state.trained = train_model(df, target, features, test_size, n_est, depth, src)
    except TrainingError as e:
        st.error(str(e))

res = st.session_state.get("trained")
if res:
    m = res["meta"]["metrics"]
    st.subheader(f"Evaluation — {res['meta']['version']}")
    c = st.columns(5)
    for col, k in zip(c, ["accuracy", "precision", "recall", "f1_score", "roc_auc"]):
        col.metric(k.replace("_", " ").title(), "n/a" if m[k] is None else f"{m[k]:.3f}")
    a, b = st.columns(2)
    a.plotly_chart(px.imshow(m["confusion_matrix"], x=m["classes"], y=m["classes"], text_auto=True,
                             labels=dict(x="Predicted", y="Actual"), color_continuous_scale="Teal", title="Confusion matrix"),
                   use_container_width=True)
    fi = pd.DataFrame(res["meta"]["feature_importance"][:15], columns=["feature", "importance"]).sort_values("importance")
    b.plotly_chart(px.bar(fi, x="importance", y="feature", orientation="h", title="Feature importance"), use_container_width=True)
    if st.button("Save model"):
        save_artifacts(res)
        if ok:
            try:
                from database.queries import save_metrics
                save_metrics({"model_name": res["meta"]["version"], **{k: m[k] for k in ["accuracy", "precision", "recall", "f1_score", "roc_auc"]}})
            except Exception as e:  # noqa: BLE001
                st.warning(f"Model saved, metrics not logged to MySQL: {e}")
        st.success("Model and preprocessing pipeline saved to models/.")
