# MONSOONIQ — fixed project

## Run on Windows

Open PowerShell in this folder.

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
python -m streamlit run app.py
```

## MySQL

1. Make sure the MySQL 8 service is running.
2. Copy `.env.example` to `.env`.
3. Put your own MySQL credentials in `.env`.
4. Do not share `.env` or commit it to Git.
5. The database named in `MYSQL_DATABASE` should already exist.

Example SQL:

```sql
CREATE DATABASE monsooniq;
```

## Dataset

A training-ready CSV is included in:

`data/uploads/mumbai_waterlogging_training_dataset.csv`

It contains 124 rows with both target classes:

- `waterlogging = 0`: 92 rows
- `waterlogging = 1`: 32 rows

The `0` label follows the project's explicit convention: no documented waterlogging event for that location/date. It should be described that way in the viva; it is not proof that flooding was physically impossible.

## Model

The saved model artifacts were intentionally removed from this clean package. Train the model from **Model Training** after importing/saving the verified dataset. This avoids stale scikit-learn model files and version-mismatch warnings.

Recommended initial features:

- `rainfall_mm`
- `latitude`
- `longitude`
- `month`
- `is_monsoon`

The app will refuse to train if the target has only one class.

## Map fix

The Mumbai Map page uses Plotly's newer `Scattermap` / MapLibre API and does not use the removed `Scattermapbox` API.
