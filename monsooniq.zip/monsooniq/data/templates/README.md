# Dataset template

`waterlogging_dataset_template.csv` contains headers only — no data. Fill it with VERIFIED records
(e.g. IMD rainfall, BMC/MCGM disaster-cell waterlogging reports, news-verified incidents).

| Column | Required | Description |
|---|---|---|
| date | yes | `YYYY-MM-DD` or `YYYY-MM-DD HH:MM` |
| location_name | yes | e.g. `Hindmata`, `Andheri Subway` |
| latitude / longitude | yes | decimal degrees (Mumbai ≈ 18.85–19.30 N, 72.75–73.05 E) |
| rainfall_mm | yes | rainfall for the period (mm) |
| temperature | no | °C |
| humidity | no | % |
| wind_speed | no | m/s |
| waterlogging | yes (for training) | 1 = waterlogging observed, 0 = not observed |
| severity | no | Low / Moderate / High |
| duration_hours | no | hours |
| source | recommended | citation of the data source |

Extra columns are allowed and can be selected as model features.
