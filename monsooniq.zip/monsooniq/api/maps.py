"""Mumbai geocoding without Google Maps.

Uses OpenStreetMap Nominatim for place-name -> latitude/longitude lookup.
The actual map display should use Plotly + OpenStreetMap tiles, so no
Google API key is required.
"""

import os
from functools import lru_cache

import requests
from dotenv import load_dotenv

load_dotenv()

MUMBAI_BBOX = (18.85, 72.75, 19.30, 73.05)  # south, west, north, east
MUMBAI_CENTER = (19.076, 72.8777)

NOMINATIM_URL = "https://nominatim.openstreetmap.org/search"


class GeocodeError(Exception):
    pass


def provider() -> str:
    return "OpenStreetMap Nominatim"


def in_mumbai(lat: float, lon: float) -> bool:
    south, west, north, east = MUMBAI_BBOX
    return south <= lat <= north and west <= lon <= east


@lru_cache(maxsize=128)
def _search_location_cached(query: str, limit: int) -> tuple:
    south, west, north, east = MUMBAI_BBOX

    user_agent = os.getenv(
        "NOMINATIM_USER_AGENT",
        "MONSOONIQ-Mumbai-Waterlogging-Intelligence/1.0",
    )

    try:
        response = requests.get(
            NOMINATIM_URL,
            timeout=10,
            params={
                "q": f"{query}, Mumbai, India",
                "format": "jsonv2",
                "limit": limit,
                "viewbox": f"{west},{north},{east},{south}",
                "bounded": 1,
                "countrycodes": "in",
            },
            headers={
                "User-Agent": user_agent,
                "Accept-Language": "en",
            },
        )
        response.raise_for_status()
        data = response.json()

    except requests.RequestException as exc:
        raise GeocodeError(
            f"OpenStreetMap geocoding service unavailable: {exc}"
        ) from exc
    except ValueError as exc:
        raise GeocodeError(
            "OpenStreetMap returned an invalid response."
        ) from exc

    results = []
    for item in data:
        try:
            lat = float(item["lat"])
            lon = float(item["lon"])
        except (KeyError, TypeError, ValueError):
            continue

        if in_mumbai(lat, lon):
            results.append(
                {
                    "name": item.get("display_name", query),
                    "latitude": lat,
                    "longitude": lon,
                }
            )

    return tuple(results[:limit])


def search_location(query: str, limit: int = 5) -> list[dict]:
    query = (query or "").strip()

    if len(query) < 2:
        raise GeocodeError("Enter at least 2 characters.")

    limit = max(1, min(int(limit), 10))
    return list(_search_location_cached(query.lower(), limit))
