"""Current weather via Open-Meteo (no API key required)."""

from datetime import datetime
from zoneinfo import ZoneInfo

import requests
from dotenv import load_dotenv

load_dotenv()

URL = "https://api.open-meteo.com/v1/forecast"


class WeatherError(Exception):
    pass


def is_configured() -> bool:
    return True


def get_current_weather(lat: float, lon: float) -> dict:
    params = {
        "latitude": lat,
        "longitude": lon,
        "current": "temperature_2m,relative_humidity_2m,precipitation,wind_speed_10m",
        "temperature_unit": "celsius",
        "wind_speed_unit": "kmh",
        "precipitation_unit": "mm",
        "timezone": "Asia/Kolkata",
    }

    try:
        r = requests.get(URL, params=params, timeout=10)
        r.raise_for_status()
        data = r.json()
    except requests.RequestException as e:
        raise WeatherError(f"Weather API unavailable: {e}") from e
    except (ValueError, TypeError) as e:
        raise WeatherError(f"Invalid weather API response: {e}") from e

    current = data.get("current", {})

    if not current:
        raise WeatherError("Weather API returned no current weather data.")

    timestamp = current.get("time", "n/a")

    if timestamp != "n/a":
        try:
            dt = datetime.fromisoformat(timestamp)

            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=ZoneInfo("Asia/Kolkata"))

            timestamp = dt.strftime("%Y-%m-%d %H:%M")

        except ValueError:
            pass

    return {
        "rainfall_mm": float(current.get("precipitation", 0.0) or 0.0),
        "rainfall_window": "current",
        "temperature": current.get("temperature_2m"),
        "humidity": current.get("relative_humidity_2m"),
        "wind_speed": current.get("wind_speed_10m"),
        "condition": "Current conditions",
        "timestamp": timestamp,
        "source": "Open-Meteo",
    }