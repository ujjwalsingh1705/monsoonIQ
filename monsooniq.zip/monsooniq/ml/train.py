"""Train and persist the MONSOONIQ Random Forest model."""
from datetime import datetime
from pathlib import Path

import joblib
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split

from ml.evaluate import evaluate
from ml.preprocessing import add_date_features, build_preprocessor, feature_names

MODEL_DIR = Path(__file__).resolve().parent.parent / "models"
MODEL_PATH = MODEL_DIR / "model.joblib"
PRE_PATH = MODEL_DIR / "preprocessing.joblib"
MIN_ROWS = 30


class TrainingError(Exception):
    pass


def train_model(
    df: pd.DataFrame,
    target: str,
    features: list[str],
    test_size: float = 0.2,
    n_estimators: int = 300,
    max_depth: int | None = None,
    dataset_name: str = "",
) -> dict:
    """Train a binary/multiclass Random Forest with validation and safe splitting."""
    df = add_date_features(df)

    if target not in df.columns:
        raise TrainingError(f"Target column '{target}' not found.")

    missing_features = [f for f in features if f not in df.columns]
    if missing_features:
        raise TrainingError(f"Features not in dataset: {missing_features}")
    if not features:
        raise TrainingError("Select at least one feature.")

    df = df.dropna(subset=[target]).copy()
    if len(df) < MIN_ROWS:
        raise TrainingError(
            f"Insufficient training data: {len(df)} labelled rows "
            f"(minimum {MIN_ROWS})."
        )

    y = pd.to_numeric(df[target], errors="coerce")
    if y.isna().any():
        raise TrainingError("Target contains non-numeric labels.")
    if not set(y.unique()).issubset({0, 1}):
        raise TrainingError("This project expects a binary waterlogging target containing only 0 and 1.")
    y = y.astype(int)

    counts = y.value_counts().sort_index()
    if len(counts) < 2:
        raise TrainingError("Target has only one class — need both positive and negative examples.")
    if counts.min() < 2:
        raise TrainingError("Each class needs at least 2 rows so the train/test split can be evaluated safely.")

    # Stratification is important for a waterlogging classifier so both classes
    # are represented in train and test sets.
    X_train, X_test, y_train, y_test = train_test_split(
        df[features],
        y,
        test_size=test_size,
        random_state=42,
        stratify=y,
    )

    if y_train.nunique() < 2:
        raise TrainingError("Training split contains only one class. Increase the dataset or test split.")

    pre, num, cat = build_preprocessor(df, features)
    Xtr = pre.fit_transform(X_train)
    Xte = pre.transform(X_test)

    model = RandomForestClassifier(
        n_estimators=n_estimators,
        max_depth=max_depth,
        class_weight="balanced",
        random_state=42,
        n_jobs=-1,
    )
    model.fit(Xtr, y_train)

    metrics = evaluate(model, Xte, y_test)
    names = feature_names(pre) or [f"f{i}" for i in range(Xtr.shape[1])]
    importance = sorted(
        zip(names, model.feature_importances_.tolist()),
        key=lambda item: -item[1],
    )

    version = datetime.now().strftime("rf-%Y%m%d-%H%M%S")
    meta = {
        "version": version,
        "target": target,
        "features": features,
        "numeric": num,
        "categorical": cat,
        "classes": [int(c) for c in model.classes_],
        "train_size": len(X_train),
        "test_size": len(X_test),
        "dataset": dataset_name,
        "class_distribution": {str(k): int(v) for k, v in counts.items()},
        "metrics": metrics,
        "feature_importance": importance,
        "params": {
            "n_estimators": n_estimators,
            "max_depth": max_depth,
            "test_size": test_size,
        },
        "trained_at": datetime.now().isoformat(timespec="seconds"),
    }
    return {"model": model, "preprocessor": pre, "meta": meta}


def save_artifacts(result: dict) -> None:
    MODEL_DIR.mkdir(parents=True, exist_ok=True)
    joblib.dump(
        {"model": result["model"], "meta": result["meta"]},
        MODEL_PATH,
    )
    joblib.dump(result["preprocessor"], PRE_PATH)
