"""Model evaluation metrics."""
import numpy as np
from sklearn.metrics import (accuracy_score, confusion_matrix, f1_score, precision_score,
                             recall_score, roc_auc_score)


def evaluate(model, X_test, y_test) -> dict:
    y_pred = model.predict(X_test)
    classes = list(model.classes_)
    binary = len(classes) == 2
    avg = "binary" if binary else "weighted"
    pos = classes[-1] if binary else None
    kw = {"average": avg, "zero_division": 0}
    if binary:
        kw["pos_label"] = pos
    out = {
        "accuracy": float(accuracy_score(y_test, y_pred)),
        "precision": float(precision_score(y_test, y_pred, **kw)),
        "recall": float(recall_score(y_test, y_pred, **kw)),
        "f1_score": float(f1_score(y_test, y_pred, **kw)),
        "roc_auc": None,
        "confusion_matrix": confusion_matrix(y_test, y_pred, labels=classes).tolist(),
        "classes": [str(c) for c in classes],
    }
    try:
        proba = model.predict_proba(X_test)
        if binary:
            out["roc_auc"] = float(roc_auc_score(np.asarray(y_test) == pos, proba[:, 1]))
        elif len(np.unique(y_test)) == len(classes):
            out["roc_auc"] = float(roc_auc_score(y_test, proba, multi_class="ovr", labels=classes))
    except ValueError:
        pass
    return out
