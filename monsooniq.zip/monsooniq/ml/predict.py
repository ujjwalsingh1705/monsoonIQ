"""Load persisted artifacts and produce a risk estimate."""
from datetime import datetime

import joblib
import pandas as pd
import streamlit as st

from ml.preprocessing import DATE_FEATURES
from ml.train import MODEL_PATH, PRE_PATH

NO_MODEL_MSG = "No trained model available. Upload verified data and train the model first."


class PredictionError(Exception):
    pass


def model_exists() -> bool:
    return MODEL_PATH.exists() and PRE_PATH.exists()


@st.cache_resource(show_spinner=False)
def _load(mtime: float):
    bundle = joblib.load(MODEL_PATH)
    return bundle["model"], joblib.load(PRE_PATH), bundle["meta"]


def load_artifacts():
    if not model_exists():
        return None
    try:
        return _load(MODEL_PATH.stat().st_mtime)
    except Exception as e:  # noqa: BLE001
        raise PredictionError(f"Saved model could not be loaded: {e}") from e


def get_meta() -> dict | None:
    try:
        artifacts = load_artifacts()
    except PredictionError:
        return None
    return artifacts[2] if artifacts else None


def categorize(p: float) -> str:
    return "Low" if p < 0.33 else ("Moderate" if p < 0.66 else "High")


def predict_risk(inputs: dict) -> dict:
    try:
        artifacts = load_artifacts()
    except PredictionError as e:
        raise e

    if not artifacts:
        raise PredictionError(NO_MODEL_MSG)

    model, pre, meta = artifacts
    now = datetime.now()
    values = dict(inputs)
    values.setdefault("month", now.month)
    values.setdefault("day_of_year", now.timetuple().tm_yday)
    values.setdefault("is_monsoon", int(now.month in (6, 7, 8, 9)))

    missing = [f for f in meta["features"] if values.get(f) is None]
    if missing:
        raise PredictionError(
            "Missing prediction features: "
            + ", ".join(missing)
            + ". Provide them or retrain the model with available features."
        )

    X = pd.DataFrame([{f: values[f] for f in meta["features"]}])

    try:
        transformed = pre.transform(X)
        proba = model.predict_proba(transformed)[0]
    except Exception as e:  # noqa: BLE001
        raise PredictionError(f"Prediction failed: {e}") from e

    classes = list(model.classes_)

    if 1 in classes:
        positive_index = classes.index(1)
        probability = float(proba[positive_index])
        category = categorize(probability)
    else:
        index = int(proba.argmax())
        probability = float(proba[index])
        label = str(classes[index])
        category = label.title() if label.title() in ("Low", "Moderate", "High") else categorize(probability)

    return {
        "risk_category": category,
        "risk_probability": probability,
        "model_version": meta["version"],
        "class_probabilities": {
            str(c): float(v) for c, v in zip(classes, proba)
        },
        "inputs": X.iloc[0].to_dict(),
    }


__all__ = ["predict_risk", "DATE_FEATURES"]
