"""Data validation, cleaning, feature engineering and the sklearn preprocessing pipeline."""
import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

REQUIRED_COLUMNS = ["date", "location_name", "latitude", "longitude", "rainfall_mm"]
OPTIONAL_COLUMNS = ["temperature", "humidity", "wind_speed", "waterlogging", "severity", "duration_hours", "source"]
NUMERIC_EXPECTED = ["latitude", "longitude", "rainfall_mm", "temperature", "humidity", "wind_speed", "duration_hours"]
DATE_FEATURES = ["month", "day_of_year", "is_monsoon"]


def validate(df: pd.DataFrame) -> dict:
    """Return a report: errors (blocking) and warnings."""
    errors, warnings = [], []
    if df.empty:
        errors.append("Dataset is empty.")
        return {"errors": errors, "warnings": warnings}
    df.columns = [c.strip().lower() for c in df.columns]
    missing = [c for c in REQUIRED_COLUMNS if c not in df.columns]
    if missing:
        errors.append(f"Missing required columns: {', '.join(missing)}")
    if "waterlogging" not in df.columns:
        warnings.append("No 'waterlogging' label column — data can be imported but not used for training.")
    elif not set(pd.to_numeric(df["waterlogging"], errors="coerce").dropna().unique()) <= {0, 1}:
        errors.append("'waterlogging' must contain only 0 or 1.")
    for c in NUMERIC_EXPECTED:
        if c in df.columns:
            bad = pd.to_numeric(df[c], errors="coerce").isna() & df[c].notna()
            if bad.any():
                errors.append(f"Column '{c}' has {int(bad.sum())} non-numeric values.")
    if "date" in df.columns:
        bad = pd.to_datetime(df["date"], errors="coerce").isna() & df["date"].notna()
        if bad.any():
            errors.append(f"'date' has {int(bad.sum())} unparseable values.")
    if {"latitude", "longitude"} <= set(df.columns):
        lat, lon = pd.to_numeric(df["latitude"], errors="coerce"), pd.to_numeric(df["longitude"], errors="coerce")
        outside = ~(lat.between(18.85, 19.30) & lon.between(72.75, 73.05))
        if outside.any():
            warnings.append(f"{int(outside.sum())} rows have coordinates outside Mumbai bounds.")
    if "rainfall_mm" in df.columns and (pd.to_numeric(df["rainfall_mm"], errors="coerce") < 0).any():
        errors.append("Negative rainfall values found.")
    dups = int(df.duplicated().sum())
    if dups:
        warnings.append(f"{dups} duplicate rows will be removed on import.")
    if "source" not in df.columns:
        warnings.append("No 'source' column — consider citing data provenance.")
    return {"errors": errors, "warnings": warnings}


def clean(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df.columns = [c.strip().lower() for c in df.columns]
    df = df.drop_duplicates()
    for c in NUMERIC_EXPECTED + ["waterlogging"]:
        if c in df.columns:
            df[c] = pd.to_numeric(df[c], errors="coerce")
    if "date" in df.columns:
        df["date"] = pd.to_datetime(df["date"], errors="coerce")
        df = df.dropna(subset=["date"])
    req = [c for c in REQUIRED_COLUMNS if c in df.columns]
    return df.dropna(subset=req).reset_index(drop=True)


def add_date_features(df: pd.DataFrame, date_col: str | None = "date") -> pd.DataFrame:
    df = df.copy()
    if date_col and date_col in df.columns:
        d = pd.to_datetime(df[date_col], errors="coerce")
        df["month"] = d.dt.month
        df["day_of_year"] = d.dt.dayofyear
        df["is_monsoon"] = d.dt.month.isin([6, 7, 8, 9]).astype(int)
    return df


def candidate_features(df: pd.DataFrame, target: str) -> list[str]:
    exclude = {target, "date", "source", "id", "severity", "duration_hours"}
    return [c for c in df.columns if c not in exclude and df[c].notna().any()]


def build_preprocessor(df: pd.DataFrame, features: list[str]) -> tuple[ColumnTransformer, list, list]:
    num = [c for c in features if pd.api.types.is_numeric_dtype(df[c])]
    cat = [c for c in features if c not in num]
    pre = ColumnTransformer([
        ("num", Pipeline([("impute", SimpleImputer(strategy="median")), ("scale", StandardScaler())]), num),
        ("cat", Pipeline([("impute", SimpleImputer(strategy="most_frequent")),
                          ("onehot", OneHotEncoder(handle_unknown="ignore"))]), cat),
    ])
    return pre, num, cat


def feature_names(pre: ColumnTransformer) -> list[str]:
    try:
        return [n.split("__", 1)[-1] for n in pre.get_feature_names_out()]
    except Exception:  # noqa: BLE001
        return []


def missing_summary(df: pd.DataFrame) -> pd.DataFrame:
    m = df.isna().sum()
    return pd.DataFrame({"missing": m, "percent": (m / max(len(df), 1) * 100).round(2)}).query("missing > 0")


__all__ = ["validate", "clean", "add_date_features", "build_preprocessor", "np"]
