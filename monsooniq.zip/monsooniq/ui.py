"""Shared UI components: hero, status strip, glass cards, AI analysis panel, chart theme."""
import html

import plotly.graph_objects as go
import plotly.io as pio
import streamlit as st

RISK_COLORS = {"Low": "#34d399", "Moderate": "#fbbf24", "High": "#f43f5e"}
CYAN, BLUE, VIOLET = "#22d3ee", "#3b82f6", "#8b5cf6"

_t = go.layout.Template(pio.templates["plotly_dark"])
_t.layout.update(
    paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
    font=dict(family="Inter Tight, sans-serif", color="#c9d3ea", size=12),
    title=dict(font=dict(family="Sora, sans-serif", size=15, color="#e8eefb"), x=0.02, xanchor="left"),
    colorway=[CYAN, BLUE, VIOLET, "#34d399", "#fbbf24", "#f43f5e"],
    xaxis=dict(gridcolor="rgba(120,160,220,0.07)", zerolinecolor="rgba(120,160,220,0.1)", linecolor="rgba(120,160,220,0.15)"),
    yaxis=dict(gridcolor="rgba(120,160,220,0.07)", zerolinecolor="rgba(120,160,220,0.1)", linecolor="rgba(120,160,220,0.15)"),
    hoverlabel=dict(bgcolor="#0e1628", bordercolor=CYAN, font=dict(family="JetBrains Mono", color="#e8eefb")),
    legend=dict(bgcolor="rgba(0,0,0,0)", font=dict(size=11)),
    margin=dict(l=48, r=20, t=56, b=40),
)
pio.templates["monsooniq"] = _t
pio.templates.default = "monsooniq"


def esc(s) -> str:
    return html.escape(str(s))


def hero() -> None:
    st.markdown("""<div class='hero'>
      <div class='hero-eyebrow'>MonsoonIQ · Mumbai</div>
      <div class='hero-title'>Predict the Rain.<br><em>Understand the Risk.</em></div>
      <div class='hero-sub'>AI-powered waterlogging intelligence for Mumbai.</div>
    </div>""", unsafe_allow_html=True)


def status_strip(items: list[tuple[str, str]]) -> None:
    """items: (label, state) with state in ok|warn|off."""
    parts = "".join(f"<span class='status-item {'off' if s == 'off' else ''}'><i class='pulse {s if s != 'ok' else ''}'></i>{esc(l)}</span>"
                    for l, s in items)
    st.markdown(f"<div class='status'><span class='status-title'>MUMBAI INTELLIGENCE STATUS</span>{parts}</div>", unsafe_allow_html=True)


def header(eyebrow: str, title: str, desc: str = "") -> None:
    st.markdown(f"<div class='page-head'><div class='page-eyebrow'>{esc(eyebrow)}</div>"
                f"<div class='page-title'>{esc(title)}</div><div class='page-desc'>{esc(desc)}</div></div>",
                unsafe_allow_html=True)


def section(title: str) -> None:
    st.markdown(f"<div class='section-title'>{esc(title)}</div>", unsafe_allow_html=True)


def card(label: str, value, note: str = "", unit: str = "", accent: str = CYAN, value_color: str | None = None,
         tag: str = "", delay: int = 0) -> None:
    style = f"--accent:{accent};" + (f"--accent-text:{value_color};" if value_color else "")
    u = f"<small>{esc(unit)}</small>" if unit else ""
    st.markdown(f"<div class='gcard delay-{delay}' style='{style}'><div class='gcard-label'><span>{esc(label)}</span><span>{esc(tag)}</span></div>"
                f"<div class='gcard-value'>{esc(value)}{u}</div><div class='gcard-note'>{esc(note)}</div><div class='spark'></div></div>",
                unsafe_allow_html=True)


def skeletons(n: int = 4) -> None:
    for c in st.columns(n):
        c.markdown("<div class='skel'></div>", unsafe_allow_html=True)


def model_offline(detail: str = "No trained model available. Upload verified data and train the model first.") -> None:
    st.markdown(f"<div class='offline'><div class='t'>MODEL OFFLINE</div><div class='d'>{esc(detail)}</div></div>", unsafe_allow_html=True)


def ai_panel(location: str, category: str, prob: float, version: str, reasons: list[tuple[str, str]]) -> None:
    color = RISK_COLORS[category]
    rs = "".join(f"<div class='ai-reason' style='animation-delay:{.1 + i * .08:.2f}s'>{esc(t)}<span>{esc(v)}</span></div>"
                 for i, (t, v) in enumerate(reasons)) or "<div class='ai-reason'>No strong driver identified from available data.</div>"
    st.markdown(f"""<div class='ai' style='--risk:{color}'>
      <div class='ai-tag'><i class='pulse'></i>AI RISK ANALYSIS</div>
      <div class='ai-loc'>{esc(location)} — <b>{category.upper()} RISK</b></div>
      <div class='ai-prob'><span class='num'>{prob * 100:.1f}%</span><span class='lbl'>RISK PROBABILITY</span></div>
      <div class='meter'><i style='width:{max(prob, .02) * 100:.1f}%'></i></div>
      <div class='ai-why'>WHY?</div>{rs}
      <div class='ai-foot'>MODEL {esc(version)} · Statistical risk estimate derived from model output and imported records — not a guaranteed flood forecast.</div>
    </div>""", unsafe_allow_html=True)


def chip(text: str, kind: str = "") -> str:
    return f"<span class='chip {kind}'>{esc(text)}</span>"


def fmt(v, nd=1):
    return "—" if v is None else (f"{v:.{nd}f}" if isinstance(v, (int, float)) else str(v))


def explain(inputs: dict, meta: dict, hist: dict) -> list[tuple[str, str]]:
    """Build reasons strictly from actual inputs, model feature importance and historical records.

    hist keys (any may be missing): incident_rain_mean, all_rain_mean, loc_incidents, avg_loc_incidents.
    """
    out = []
    imp = dict(meta.get("feature_importance", []))
    rain = inputs.get("rainfall_mm")
    if rain is not None and hist.get("incident_rain_mean") is not None:
        ref = hist["incident_rain_mean"]
        if rain >= ref:
            out.append(("Rainfall at or above the historical average on waterlogging days", f"{rain:.1f} vs {ref:.1f} mm"))
        elif hist.get("all_rain_mean") is not None and rain > hist["all_rain_mean"]:
            out.append(("Rainfall above the overall historical average", f"{rain:.1f} vs {hist['all_rain_mean']:.1f} mm"))
        else:
            out.append(("Rainfall below levels typically seen on waterlogging days", f"{rain:.1f} vs {ref:.1f} mm"))
    if hist.get("loc_incidents") is not None and hist.get("avg_loc_incidents"):
        n, avg = hist["loc_incidents"], hist["avg_loc_incidents"]
        label = "Historical incidents elevated at this location" if n > avg else "Historical incidents at or below city average"
        out.append((label, f"{n} vs avg {avg:.1f}"))
    hum = inputs.get("humidity")
    if hum is not None and hum >= 85:
        out.append(("Very high humidity reported", f"{hum:.0f}%"))
    if inputs.get("is_monsoon") == 1 and "is_monsoon" in meta.get("features", []):
        out.append(("Within the June–September monsoon window", "seasonal"))
    top = [n for n, _ in sorted(imp.items(), key=lambda t: -t[1])[:3]]
    if top:
        out.append(("Most influential model features", ", ".join(top)))
    return out
